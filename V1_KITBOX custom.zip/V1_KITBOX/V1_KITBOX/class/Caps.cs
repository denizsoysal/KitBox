﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace V1_KITBOX
{
    class Caps:Element
    {
        public Caps()
        {
            this.code = "COUPEL";
        }
    }
}
